# NANMUDHALVAN_TUESDAYBATCH_PROJECT_FILES

PROJECT CREATED BY :BARANIDHARAN S  
6235,AVS COLLEGE OF TECHNOLOGY


LOGIN DETAILS:


UNAME: baranidharan


Password:barani1234




#Project Running steps:

python manage.py makemigrations

python manage.py migrate

python manage.py createsuperuser

python manage.py runserver
